public class test
{
    public static void main(String [] args)
    {
        int count = 0;
        yes();  
        System.out.println(count);
    }
    public static void yes()
    {
        int count = 0;
        
        count++;
    }
}